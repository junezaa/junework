﻿<?php   
$host = "localhost";
$user = "root";
$password = "0078junegeo";
$db = "priceptt";
$conn = mysql_connect($host,$user,$password);
mysql_db_query ($db, 'set name utf8');
?>