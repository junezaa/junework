<?
	include ("price.php");
	$sql = "select * from ptt_price order by ptt_id";
	$result = mysql_query ($sql,$conn);
?>

<title>: : ราคาน้ำมัน : :</title>
<div id="showData" align="center">
		<p>ราคาน้ำมันวันนี้</p>
		<table border="1" align="center">
			<tr>
			<th>ลำดับ</th>
			<th>รายการน้ำมัน</th>
			<th>ราคาน้ำมัน</th>
			</tr>
		<? while ($row = mysql_fetch_array($result)) { ?>
		<tr>
				<td><? echo $row[ptt_id] ?></td>
				<td><? echo $row[petroleum_name] ?></td>
				<td><? echo $row[price] ?></td>
		</tr>
		<? } ?>
		</table>
		</div>
