<!DOCTYPE html>
<html>
<head>
<title>: : ราคาน้ำมันวันนี้ : :</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script src="http://code.jquery.com/jquery-latest.js"></script>
<meta charset=utf-8 />
<script>
function getDataFromDb()
{
$.ajax({
url: "getData2.php" ,
type: "POST",
data: ''
})
.success(function(result) {
var obj = jQuery.parseJSON(result);
if(obj != '')
{
//$("#myTable tbody tr:not(:first-child)").remove();
$("#myBody").empty();
$.each(obj, function(key, val) {
var tr = "<tr>";
tr = tr + "<td>" + val["bang_id"] + "</td>";
tr = tr + "<td>" + val["petroleum_name"] + "</td>";
tr = tr + "<td>" + val["price"] + "</td>";
tr = tr + "</tr>";
$('#myTable > tbody:last').append(tr);
});
}
});
}
setInterval(getDataFromDb, 1000);   // 1000 = 1 second
</script>
</head>
<body>
<center>
<h1>ราคาน้ำมันวันนี้</h1>
<table width="600" border="1" id="myTable">
<!-- head table -->
<thead>
<tr>
<td width="91"> <div align="center"></div></td>
<td width="120"> <div align="center">รายการน้ำมัน</div></td>
<td width="98"> <div align="center">ราคาน้ำมัน</div></td>

</tr>
</thead>
<!-- body dynamic rows -->
<tbody id="myBody"></tbody>
</table>
<center>
</body>
</html>
