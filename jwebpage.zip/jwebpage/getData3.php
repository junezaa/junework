<?php
$objConnect = mysql_connect("localhost","root","0078junegeo") or die(mysql_error());
$objDB = mysql_select_db("priceptt");
$strSQL = "SELECT * FROM caltex WHERE 1 ORDER BY caltex_id DESC ";
$objQuery = mysql_query($strSQL) or die (mysql_error());
$intNumField = mysql_num_fields($objQuery);
$resultArray = array();
while($obResult = mysql_fetch_array($objQuery))
{
$arrCol = array();
for($i=0;$i<$intNumField;$i++)
{
$arrCol[mysql_field_name($objQuery,$i)] = $obResult[$i];
}
array_push($resultArray,$arrCol);
}
mysql_close($objConnect);
echo json_encode($resultArray);
?>